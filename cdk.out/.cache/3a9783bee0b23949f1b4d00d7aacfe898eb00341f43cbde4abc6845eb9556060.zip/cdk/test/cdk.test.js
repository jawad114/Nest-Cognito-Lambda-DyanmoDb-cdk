test('SQS Queue Created', () => {
});
//# sourceMappingURL=cdk.test.js.map