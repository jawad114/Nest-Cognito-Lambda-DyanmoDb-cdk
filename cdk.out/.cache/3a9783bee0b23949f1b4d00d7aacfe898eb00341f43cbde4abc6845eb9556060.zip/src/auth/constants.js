"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JWT_SECRET = exports.COGNITO_APP_CLIENT_SECRET = exports.COGNITO_APP_CLIENT_ID = exports.COGNITO_USER_POOL_ID = exports.COGNITO_REGION = void 0;
exports.COGNITO_REGION = 'ap-south-1';
exports.COGNITO_USER_POOL_ID = 'ap-south-1_EG8J6LKux';
exports.COGNITO_APP_CLIENT_ID = '1qqndjstb7486iegq1h5vlsbn6';
exports.COGNITO_APP_CLIENT_SECRET = '1ljrhqk57npqq8vsaigp92lntcqojdkahc8q4lu7lbivf1351o4q';
exports.JWT_SECRET = 'mysecret-password-password';
//# sourceMappingURL=constants.js.map