export declare class AuthModule {
}
