export declare const COGNITO_REGION = "ap-south-1";
export declare const COGNITO_USER_POOL_ID = "ap-south-1_EG8J6LKux";
export declare const COGNITO_APP_CLIENT_ID = "1qqndjstb7486iegq1h5vlsbn6";
export declare const COGNITO_APP_CLIENT_SECRET = "1ljrhqk57npqq8vsaigp92lntcqojdkahc8q4lu7lbivf1351o4q";
export declare const JWT_SECRET = "mysecret-password-password";
