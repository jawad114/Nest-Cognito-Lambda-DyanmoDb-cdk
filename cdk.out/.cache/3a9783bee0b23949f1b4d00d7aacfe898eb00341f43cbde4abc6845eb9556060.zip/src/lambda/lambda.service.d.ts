export declare class LambdaService {
    invokeProtectedFunction(): {
        message: string;
    };
}
